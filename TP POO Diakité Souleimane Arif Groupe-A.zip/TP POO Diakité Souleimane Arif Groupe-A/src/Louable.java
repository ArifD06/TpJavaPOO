public interface Louable {public abstract void louer();
    public abstract void retourner();
}

